module orders-api

go 1.22

require modernc.org/sqlite v1.29.5
